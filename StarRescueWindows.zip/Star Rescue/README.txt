Star Rescue
Created for Global Game Jam 2021

Game design
  Josh Hertel (@herteljt)
  Casey Brant (@BaseCase)
  David Schallert (@fromage10x)

Programming
  Josh Hertel
  Casey Brant (@BaseCase)

Art
  Casey Brant (@BaseCase)

Writing
  David Schallert (@fromage10x)

Music
  Dustin Sendekas


Built in LOVE2D.

